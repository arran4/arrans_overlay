# g2

Some Gentoo CLI tools I wrote for myself.